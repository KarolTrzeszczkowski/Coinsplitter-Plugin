from electroncash.i18n import _

fullname = 'coinsplitter-plugin'
description = _('Plugin coinsplitter-plugin')
available_for = ['qt']
