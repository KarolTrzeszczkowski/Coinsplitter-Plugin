# Electron Cash Coinsplitter plugin
This is [Mark's Lundeberg's coinsplitter](https://github.com/markblundeberg/coinsplitter) ported to the plugin architecture. 

All of the user guides can be found in description of the oryginal coinsplitter. The main difference is that now coinsplitter is in the new tab, not a dialog in the menu. You also need a separate plugin ([BSV Plugin](https://github.com/KarolTrzeszczkowski/Electron-Cash-BSV-Plugin)) to access your funds on the BSV chain via Electron Cash. Make sure you read BSV Plugin README.md before using it. You can import your private keys to a different wallet app if you do't want to use BSV Plugin.
